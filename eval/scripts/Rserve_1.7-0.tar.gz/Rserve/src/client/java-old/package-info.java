/** 
 * old (deprecated) client interface to <a href="http://www.rosuda.org/Rserve/">Rserve</a>
 *
 * <p>The new REngine-based interface defined in the <code>org.rosuda.REngine.Rserve</code> is recommended
 */
package org.rosuda.JRclient ;

